To run the test all that is needed is to copy CardGameTest.java and CardGameTest.class and all the other files in the test folder (this folder) to where CardGame.java is stored. 
Java and all it's associated class files are the tests use junit 4.13.1 Copy the org folder into the CardGame folder and the .iml file. 
To test a specific file and number of players just edit the filepath variable in the test and enter the number of players playing. 
This should be located near the top of the file. The test files are called three.txt and deck.txt for 3 and 2 players respectively.